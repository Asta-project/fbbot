import chalk from 'chalk';
import fs from 'fs';
import path from 'path';
import gradient from 'gradient-string';
import pkg from 'facebook-chat-api';
import config from './config.js';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
const _filename = fileURLToPath(import.meta.url);
const __dirname = dirname(_filename);
// Display styled banner on startup
function showBanner() {
  console.clear();
  const botName = config.botName.toUpperCase();
  const maker = "Made by Nexus Coders";
  console.log(` #################################################### # # # ${botName.padStart((50 + botName.length) / 2).padEnd(50)} # # # #################################################### ${maker.padStart((50 + maker.length) / 2).padEnd(50)} `);
  console.log(gradient.pastel(` #################################################### # # # NEXUS BOT # # # #################################################### `));
}

// Global variables
const commands = new Map();
const cooldowns = new Map();
const events = new Map();
const failedCommands = [];
const failedEvents = [];

// Load all commands dynamically
async function loadCommands() {
  const commandPath = path.join(__dirname, ".", "src", "commands");
  const files = fs.readdirSync(commandPath);
  for (const file of files) {
    if (file.endsWith(".js")) {
      try {
        const command = await import(path.join(commandPath, file));
        commands.set(command.default.config.name, command.default);
      } catch (err) {
        failedCommands.push(file);
      }
    }
  }
}

// Load all events dynamically
async function loadEvents() {
  const eventPath = path.join(__dirname, ".", "src", "events");
  const files = fs.readdirSync(eventPath);
  for (const file of files) {
    if (file.endsWith(".js")) {
      try {
        const event = await import(path.join(eventPath, file));
        events.set(event.default.config.name, event.default);
      } catch (err) {
        failedEvents.push(file);
      }
    }
  }
}

// Login to Facebook
 async function login() {
   showBanner();
   pkg({ email: config.email, password: config.password }, (err, api) => {
     if (err && err.error === 'Wrong username/password.') {
       console.log(chalk.yellow("Email and password login failed. Trying appState..."));
       tryAppStateLogin();
     } else if (err) {
       console.error(chalk.red("Login Error:"), err);
       process.exit(1);
     } else {
       appState = api.getAppState();
       fs.writeFileSync("appState.json", JSON.stringify(appState));
       main(api);
     }
   });
 }

 function tryAppStateLogin() {
   let appState;
   try {
     const appStateData = fs.readFileSync("appState.json", "utf8");
     if (!appStateData) {
       console.log(chalk.red("Appstate not found. Please login with email and password."));
       process.exit(1);
     } else {
       appState = JSON.parse(appStateData);
       console.log(chalk.yellow("Logging in with appState..."));
       pkg({ appState }, (err, api) => {
           if (err) {
           console.log(chalk.red("Appstate login failed. Please check your appState.json file."));
           process.exit(1);
         } else {
           main(api);
         }
       });
     }
   } catch (error) {
     console.log(chalk.red("Error loading appState. Please make sure the appState.json file exists and is valid."));
    process.exit(1);
   }
}

// Main function
async function main(api) {
  await loadCommands();
  await loadEvents();
  api.listenMqtt((err, message) => {
    if (err) {
      console.error(chalk.red("Error:"), err);
      return;
    }
    // Execute events
    events.forEach(event => {
      if (event.onMessage) event.onMessage({ api, message, config });
    });
    // Handle commands
    const prefix = config.prefix;
    if (!message.body || !message.body.startsWith(prefix)) return;
    const args = message.body.slice(prefix.length).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();
    if (!commands.has(commandName)) return;
    const command = commands.get(commandName);
    const now = Date.now();
    // Enforce cooldown
    if (!cooldowns.has(commandName)) cooldowns.set(commandName, new Map());
    const timestamps = cooldowns.get(commandName);
    const cooldownAmount = (command.config.cooldown || config.cooldownTime) * 1000;
    if (timestamps.has(message.senderID)) {
      const expirationTime = timestamps.get(message.senderID) + cooldownAmount;
      if (now < expirationTime) return;
    }
    timestamps.set(message.senderID, now);
    setTimeout(() => timestamps.delete(message.senderID), cooldownAmount);
    // Execute command's onStart function
    if (command.onStart) {
      command.onStart({ api, message, event: message, args, config });
    }
    // Execute command's run function
    if (command.run) {
      command.run({ api, message, event: message, args, config });
    }
  });
};

// Login to Facebook
login();