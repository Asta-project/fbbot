export default {
    adminIds: ["1234567890", "0987654321"],
    cooldownTime: 5,
    autoRestartTime: 60 * 60 * 1000,
    prefix: "!",
    welcomeMessage: "Welcome to the group, {user}!",
    botName: "NEXUS",
    email: "samueladebero778@gmail.com",
    password: "asta@0123",
  };