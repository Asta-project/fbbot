module.exports = {
    config: {
        name: "hello",
        version: "1.0",
        author: "YourName",
        cooldown: 5,
        role: 0,
        description: "Say hello to the bot",
        category: "general",
        usage: "hello",
    },
    onStart: async function ({ api, message }) {
        api.sendMessage("Hello there! How can I assist you?", message.threadID);
    },
};
