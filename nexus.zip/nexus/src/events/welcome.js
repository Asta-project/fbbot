module.exports = {
    config: {
        name: "welcome", // Unique name for the event
    },
    onMessage: async function ({ api, message, config }) {
        // Check if it's a group join event
        if (message.logMessageType === "log:subscribe") {
            const newUser = message.logMessageData.addedParticipants[0].fullName;
            const threadID = message.threadID;

            // Send a welcome message
            api.sendMessage(
                config.welcomeMessage.replace("{user}", newUser),
                threadID
            );
        }
    },
};
